package com.example.cryptocurrency.model

data class CryptoModel(
    val currency: String,
    val price: String
)